/* Minimal service worker: enables PWA installability + offline shell fallback. */
const CACHE = 'goldbot-v1'
const ASSETS = ['/', '/manifest.json', '/icons/icon-192.png', '/icons/icon-512.png']

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()))
})

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())
  )
})

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url)
  // never cache websocket / engine traffic
  if (url.searchParams.has('XTransformPort') || url.pathname.startsWith('/socket.io')) return
  if (event.request.method !== 'GET' || !url.origin.startsWith('http')) return
  event.respondWith(
    fetch(event.request)
      .then(res => {
        if (res.ok && url.origin === self.location.origin) {
          const clone = res.clone()
          caches.open(CACHE).then(c => c.put(event.request, clone)).catch(() => {})
        }
        return res
      })
      .catch(() => caches.match(event.request).then(hit => hit || caches.match('/')))
  )
})
